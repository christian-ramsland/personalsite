package com.ramsland.psbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PsbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsbackendApplication.class, args);
	}

}
