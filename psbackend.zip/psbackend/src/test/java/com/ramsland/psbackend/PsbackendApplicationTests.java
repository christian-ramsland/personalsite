package com.ramsland.psbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PsbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
